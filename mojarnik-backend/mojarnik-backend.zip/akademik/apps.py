from django.apps import AppConfig


class AkademikConfig(AppConfig):
    name = 'akademik'
