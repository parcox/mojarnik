from django.apps import AppConfig


class EmodulConfig(AppConfig):
    name = 'emodul'
